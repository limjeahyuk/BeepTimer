//
//  BeepTimerWidgetBundle.swift
//  BeepTimerWidget
//
//  Created by 임재혁 on 11/13/25.
//

import WidgetKit
import SwiftUI

@main
struct BeepTimerWidgetBundle: WidgetBundle {
    var body: some Widget {
//        BeepTimerWidget()
//        BeepTimerWidgetControl()
        BeepTimerWidgetLiveActivity()
    }
}
