//
//  BeepTimerApp.swift
//  BeepTimer
//
//  Created by 임재혁 on 8/2/25.
//

import SwiftUI

@main
struct BeepTimerApp: App {
    var body: some Scene {
        WindowGroup {
            TimerPager()
        }
    }
}
